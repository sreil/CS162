#include "f.h"
#include <iostream>

void F::f()
{
	std::cout << "This was function f!" << std::endl;
}
