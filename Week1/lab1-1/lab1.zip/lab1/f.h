#ifndef F_H_INCLUDED
#define F_H_INCLUDED

class F
{
public:
	void f();
};

#endif // F_H_INCLUDED
