#include <iostream>
#include "f.h"
#include "g.h"

using namespace std;

int main()
{
	F f;
	G g;

	f.f();
	g.g();

	return 0;
}
