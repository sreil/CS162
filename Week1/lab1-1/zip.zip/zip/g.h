#ifndef G_H_INCLUDED
#define G_H_INCLUDED

class G
{
public:
	void g();
};

#endif // G_H_INCLUDED
