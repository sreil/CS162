#include "g.h"
#include <iostream>

void G::g()
{
	std::cout << "This was function g!" << std::endl;
}
