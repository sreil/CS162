/*********************************************************************
** Author: Sean Reilly
** Date: May 1, 2015 CS-162
** Description: copies to another file
*********************************************************************/

#include "copy.h"

using namespace std;

char CopyFilter::transform(char ch)
{
	return ch;
}